let data;

// تحميل البيانات أولاً
fetch("data.json")
  .then(res => res.json())
  .then(json => {
    data = json;
    // ممكن تفتح قسم تلقائياً بعد تحميل البيانات، مثلاً الدروس:
    showSection("lessons");
  });

function showSection(section){
  if(!data) return; // إذا البيانات ما حملتش، ما ندير والو
  let html = "";

  // الحروف
  if(section === "letters"){
    data.letters.forEach(l=>{
      html += `<div class="card">
        <h2>${l.jp}</h2>
        <p>Romaji: ${l.romaji}</p>
        <p>العربية: ${l.ar}</p>
        <p>مثال: ${l.example}</p>
        <button onclick="speak('${l.jp}')">🔊 استمع للنطق</button>
      </div>`;
    });
  }

  // الكلمات
  if(section === "words"){
    data.words.forEach(w=>{
      html += `<div class="card">
        <h3>${w.jp}</h3>
        <p>Romaji: ${w.romaji}</p>
        <p>العربية: ${w.ar}</p>
        <button onclick="speak('${w.jp}')">🔊 استمع للنطق</button>
      </div>`;
    });
  }

  // القواعد
  if(section === "grammar"){
    data.grammar.forEach(g=>{
      html += `<div class="card">
        <h3>${g.title}</h3>
        <p>مثال: ${g.example}</p>
        <p>شرح: ${g.explain}</p>
      </div>`;
    });
  }

  // الدروس
  if(section === "lessons"){
    data.lessons.forEach(l=>{
      html += `<div class="card">
        <h3>درس ${l.id}: ${l.title}</h3>
        <p>${l.content}</p>
      </div>`;
      localStorage.setItem('lastLesson', l.id);
      document.getElementById('progress').innerText = "آخر درس مفتوح: " + l.id;
    });
  }
if(section === "animal" && data.animal){
    data.animal.forEach(a => {
      html += `<div class="card">
        <h3>${a.jp}</h3>
        <p>Romaji: ${a.romaji}</p>
        <p>العربية: ${a.ar}</p>
        <button onclick="speak('${a.jp}')">🔊 استمع للنطق</button>
      </div>`;
    });
}
  // الألوان
  if(section === "colors" && data.colors){
    data.colors.forEach(c => {
      html += `<div class="card">
        <h3>${c.jp}</h3>
        <p>Romaji: ${c.romaji}</p>
        <p>العربية: ${c.ar}</p>
        <button onclick="speak('${c.jp}')">🔊 استمع للنطق</button>
      </div>`;
    });
  }
  
  // الأرقام
  if(section === "numbers" && data.numbers){
    data.numbers.forEach(n => {
      html += `<div class="card">
        <h3>${n.jp}</h3>
        <p>Romaji: ${n.romaji}</p>
        <p>العربية: ${n.ar}</p>
        <button onclick="speak('${n.jp}')">🔊 استمع للنطق</button>
      </div>`;
    });
  }
if(section === "phrases" && data.phrases){
    data.phrases.forEach(p => {
        html += `<div class="card">
            <h3>${p.jp}</h3>
            <p>Romaji: ${p.romaji}</p>
            <p>العربية: ${p.ar}</p>
            <button onclick="speak('${p.jp}')">🔊 استمع للنطق</button>
        </div>`;
    });
}
  document.getElementById("content").innerHTML = html || "لا توجد نتائج";
}
//اختبار
 // بيانات الكويز كاملة
// ---------- بيانات الكويز ----------
const quizData = [
  { jp: "mizu", options: ["مظلة", "ماء", "سماء"], answer: "ماء" },
  { jp: "inu", options: ["قط", "كلب", "زهرة"], answer: "كلب" },
  { jp: "kuruma", options: ["سيارة", "جسر", "كتاب"], answer: "سيارة" },
  { jp: "yama", options: ["ماء", "جبل", "كلب"], answer: "جبل" },
  { jp: "hana", options: ["كلب", "سيارة", "زهرة"], answer: "زهرة" },
  { jp: "neko", options: ["كلب", "قط", "بيت"], answer: "قط" },
  { jp: "hon", options: ["ماء", "سيارة", "كتاب"], answer: "كتاب" },
  { jp: "gakkou", options: ["بيت", "مدرسة", "جبل"], answer: "مدرسة" },
  { jp: "taberu", options: ["يأكل", "يشرب", "ينام"], answer: "يأكل" },
  { jp: "nomu", options: ["يأكل", "يشرب", "يذهب"], answer: "يشرب" },
  { jp: "iku", options: ["يأتي", "يشاهد", "يذهب"], answer: "يذهب" },
  { jp: "kuru", options: ["يأتي", "يأكل", "يشرب"], answer: "يأتي" },
  { jp: "miru", options: ["يشاهد", "يذهب", "ينام"], answer: "يشاهد" },
  { jp: "kiku", options: ["يسمع", "يتحدث", "يأكل"], answer: "يسمع" },
  { jp: "hanasu", options: ["يسمع", "يتحدث", "يشرب"], answer: "يتحدث" },
  { jp: "neru", options: ["يأكل", "يشرب", "ينام"], answer: "ينام" },
  { jp: "kawa", options: ["نهر", "بحيرة", "غابة"], answer: "نهر" },
  { jp: "mori", options: ["نهر", "بحيرة", "غابة"], answer: "غابة" },
  { jp: "kaigan", options: ["ساحل", "مطار", "شارع"], answer: "ساحل" },
  { jp: "mizuumi", options: ["ساحل", "بحيرة", "نهر"], answer: "بحيرة" },
  { jp: "kuukou", options: ["مطار", "محطة", "حديقة"], answer: "مطار" },
  { jp: "eki", options: ["مطار", "محطة", "مدرسة"], answer: "محطة" },
  { jp: "mise", options: ["مستشفى", "مدرسة", "متجر"], answer: "متجر" },
  { jp: "byouin", options: ["مستشفى", "محطة", "سوق"], answer: "مستشفى" },
  { jp: "toshokan", options: ["مدرسة", "حديقة", "مكتبة"], answer: "مكتبة" },
  { jp: "kouen", options: ["مطار", "حديقة", "متجر"], answer: "حديقة" },
  { jp: "yuubinkyoku", options: ["مكتب بريد", "مكتبة", "محطة"], answer: "مكتب بريد" },
  { jp: "ginkou", options: ["مطار", "حديقة", "بنك"], answer: "بنك" },
  { jp: "eigakan", options: ["سينما", "مكتبة", "مدرسة"], answer: "سينما" },
  { jp: "bijutsukan", options: ["سينما", "متحف فني", "حديقة"], answer: "متحف فني" },
  { jp: "hoteru", options: ["فندق", "مكتبة", "مدرسة"], answer: "فندق" },
  { jp: "hashi", options: ["جسر", "شارع", "مدرسة"], answer: "جسر" },
  { jp: "toori", options: ["جسر", "شارع رئيسي", "حديقة"], answer: "شارع رئيسي" },
  { jp: "ichiba", options: ["سوق", "مستشفى", "فندق"], answer: "سوق" },
  { jp: "denki", options: ["كهرباء", "هاتف", "كتاب"], answer: "كهرباء" },
  { jp: "suidou", options: ["مياه", "كهرباء", "شارع"], answer: "مياه" },
  { jp: "denwa", options: ["هاتف", "ماء", "كتاب"], answer: "هاتف" },
  { jp: "tokei", options: ["ساعة", "قلم", "مظلة"], answer: "ساعة" },
  { jp: "kasa", options: ["مظلة", "قبعة", "حذاء"], answer: "مظلة" },
  { jp: "boushi", options: ["قبعة", "مظلة", "قميص"], answer: "قبعة" },
  { jp: "kutsu", options: ["حذاء", "قبعة", "ملابس"], answer: "حذاء" },
  { jp: "fuku", options: ["ملابس", "حذاء", "قميص"], answer: "ملابس" }
];

// ---------- عرض الكويز ----------
function showQuiz() {
    const container = document.getElementById("content");
    container.innerHTML = ""; // مسح المحتوى القديم

    quizData.forEach(q => {
        let card = document.createElement("div");
        card.classList.add("card");
        card.innerHTML = `
            ❓ ما معنى "${q.jp}"?<br><br>
            ${q.options.map(opt => `<button onclick="checkAnswer('${opt}', '${q.answer}')">${opt}</button>`).join(" ")}
        `;
        container.appendChild(card);
    });
}

// ---------- التحقق من الإجابة ----------
function checkAnswer(selected, correct) {
    if (selected === correct) {
        alert("صحيح ✅");
    } else {
        alert("خطأ ❌");
    }
}

  document.getElementById("content").innerHTML = html;

function searchLessons(term){
  if(!data) return;
  let html = "";

  term = term.toLowerCase();

  // بحث في الكلمات
  data.words.forEach(w=>{
    if(w.jp.includes(term) || w.ar.includes(term) || w.romaji.includes(term)){
      html += `<div class="card">
      <h3>${w.jp}</h3>
      <p>Romaji: ${w.romaji}</p>
      <p>العربية: ${w.ar}</p>
      </div>`;
    }
  });
document.getElementById("content").innerHTML = html; // ⚠️ عرض كل شيء بعد الشروط
// ⚠️ هذا القوس يسكر دالة showSection
  // بحث في الحروف
  data.letters.forEach(l=>{
    if(l.jp.includes(term) || l.ar.includes(term) || l.romaji.includes(term)){
      html += `<div class="card">
      <h2>${l.jp}</h2>
      <p>Romaji: ${l.romaji}</p>
      <p>العربية: ${l.ar}</p>
      <p>مثال: ${l.example}</p>
      </div>`;
    }
  });

  document.getElementById("content").innerHTML = html || "لا توجد نتائج";
}
const toggle = document.getElementById('modeToggle');

toggle.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
  document.body.classList.toggle('light-mode');
});
function speak(text){
  let msg = new SpeechSynthesisUtterance(text);
  speechSynthesis.speak(msg);
}
function speak(text){
  const msg = new SpeechSynthesisUtterance(text);
  msg.lang = "ja-JP";
  speechSynthesis.speak(msg);
}
